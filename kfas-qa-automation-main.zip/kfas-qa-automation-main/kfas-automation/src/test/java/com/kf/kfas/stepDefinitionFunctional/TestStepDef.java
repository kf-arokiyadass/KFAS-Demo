package com.kf.kfas.stepDefinitionFunctional;


import com.kf.kfas.pageObjectsFunctional.Test;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import reusable.TestBase;

public class TestStepDef extends TestBase {
	private Test test;
	
	public TestStepDef() throws Exception {
		test = new Test();
	}
	
	
	@When("User is in Login page")
	public void user_is_in_login_page() {
	    test.user_is_in_login_page();
	}

	@Then("User name text box should be displayed in login page")
	public void user_name_text_box_should_be_displayed_in_login_page() {
	    test.user_name_text_box_should_be_displayed_in_login_page();
	

}
}
