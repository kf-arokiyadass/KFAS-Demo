package com.kf.kfas.runner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import dataProviders.ConfigProperties;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import reusable.TestBase;
import reusable.UIHelpers;


@CucumberOptions(features = {
		"src/test/resources/features/featuresFunctional" }, tags = "(@KFASLogin)", glue = {
				"com/kf/kfas/stepDefinitionFunctional" }, plugin = { "pretty", "html:target/cucumber-reports/test_runner.html",
						"json:target/cucumber-reports/test_runner.json" }, monochrome = true, dryRun = false)

public class TestRunner extends AbstractTestNGCucumberTests {
	TestBase testBase;

	@BeforeClass
	public void setUpBrowser() throws Exception {
		testBase = new TestBase();
		testBase.init(ConfigProperties.getConfigProperties().getString("browser"), "APP_URL");
		Thread.sleep(5000);
	}

	@AfterClass
	public void generateReport() {
		File reportOutputDirectory = new File("target/reports");
		List<String> jsonFiles = new ArrayList<String>();
		jsonFiles.add("target/cucumber-reports/test_runner.json");
		String projectName = "KFASApplication";
		String buildNumber = "v1.1";
		Configuration configuration = new Configuration(reportOutputDirectory, projectName);
		configuration.setBuildNumber(buildNumber);
		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		// reportBuilder.generateReports();
		UIHelpers.quitBrowser();
	}
}
