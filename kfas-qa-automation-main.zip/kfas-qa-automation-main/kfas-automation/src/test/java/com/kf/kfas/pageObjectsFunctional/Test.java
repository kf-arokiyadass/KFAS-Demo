package com.kf.kfas.pageObjectsFunctional;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import reusable.UIHelpers;


public class Test extends UIHelpers {
	public Test() throws IOException
	{
		PageFactory.initElements(driver, this);
	}
	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	@FindBy(xpath = "//*[contains(text(),'Log in to your account')]")
	public WebElement login_test;
	
	@FindBy(xpath = "//*[@placeholder='Enter username']")	
	public WebElement username_placeholder;

	public void user_is_in_login_page() {
		wait.until(ExpectedConditions.visibilityOf(login_test)).isDisplayed();
		
	}

	public void user_name_text_box_should_be_displayed_in_login_page() {
		wait.until(ExpectedConditions.visibilityOf(username_placeholder)).isDisplayed();
		
	}
	
}
