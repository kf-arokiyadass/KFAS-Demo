package reusable;

import dataProviders.ConfigProperties;
import enums.Browsers;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.config.OperatingSystem;
import io.github.bonigarcia.wdm.managers.*;
import loggers.LoggerHelper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.safari.SafariDriver;
import utils.DriverBuilder;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class TestBase {
    public static WebDriver driver;
    public static long page_Load_Timeout = 60;
    public static long implicit_Wait = 20;
    public static long explicit_Wait = 30;
    private final Logger log = LoggerHelper.getLogger(TestBase.class);

    // initialize browser
    public void init(String browser, String baseUrl) {
        driver = DriverBuilder.createDriver(browser);
        UIHelpers.executor = ((JavascriptExecutor) driver);
        String url = ConfigProperties.getConfigProperties().getString(baseUrl);
        driver.get(url);
        log.info(url + "is fetched");
    }

    // initialize browser for API feature
    public void initAPI(String browser) throws IOException {
        if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
            WebDriverManager webDriverManager = new ChromeDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.chromedriver().clearCache();
            WebDriverManager.chromedriver().setup();
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("--no-sandbox");
            chromeOptions.addArguments("--disable-gpu");
            chromeOptions.addArguments("disable-notifications");
            chromeOptions.addArguments("--disable-dev-shm-usage");
            chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
            chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200",
                    "--ignore-certificate-errors");

            if(ConfigProperties.getConfigProperties().checkPropertyExists("DOWNLOAD_PATH")) {
                String downloadPath = ConfigProperties.getConfigProperties().getString("DOWNLOAD_PATH");
                if (downloadPath != null) {
                    Map<String, Object> prefs = new HashMap<String, Object>();
                    prefs.put("download.default_directory", downloadPath);
                    chromeOptions.setExperimentalOption("prefs", prefs);
                }
            }
            driver = new ChromeDriver(chromeOptions);
        }

        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
    }
}
