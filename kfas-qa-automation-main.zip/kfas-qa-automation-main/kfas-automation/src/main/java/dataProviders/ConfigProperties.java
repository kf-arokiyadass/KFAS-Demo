package dataProviders;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ConfigProperties {
    public static final String PROPERTIES_FILE_PATH = "src/test/resources/testDataResources/";
    private static ConfigProperties configProperties;
    private static final String ENVIRONMENT_PROPERTY = "QA_AUTOMATION_ENVIRONMENT";
    private static final String PROPERTIES_FILE_NAME = "config.properties";
    private Properties props;

    private ConfigProperties() {
        String configFilePath = getConfigFilePath();
        FileInputStream fileInput;
        try {
            fileInput = new FileInputStream(configFilePath);
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Couldn't find the file: " + configFilePath, e);
        }
        try {
            props = new Properties();
            props.load(fileInput);
        } catch (IOException e) {
            throw new RuntimeException("Couldn't load the file: " + configFilePath, e);
        }
    }

    public boolean checkPropertyExists(String propName){
        boolean propertyExists = true;
        try {
            String propVal = this.getProperty(propName);
        }
        catch(Exception e)
        {
            propertyExists = false;
        }
        return propertyExists;
    }

    private String getProperty(String propName){
        String propVal = props.getProperty(propName);
        if (propVal == null) {
            throw new RuntimeException("Unknown property " + propName);
        }
        return propVal;
    }

    public static ConfigProperties getConfigProperties() {
        if (configProperties == null) {
            configProperties = new ConfigProperties();
        }
        return configProperties;
    }

    public boolean getBoolean(String propName) {
        String propVal = this.getProperty(propName);
        return Boolean.parseBoolean(propVal);
    }

    public int getInt(String propName) {
        String propVal = this.getProperty(propName);
        return Integer.parseInt(propVal);
    }

    public String getString(String propName) {
        return this.getProperty(propName);
    }

    /**
     * Load configuration property file based on runtime property "environment"
     *
     * The "environment" contains the environment the system is currently running
     * against e.g. test, staging, production
     *
     * Use the default properties file if "environment" is not specified.
     *
     * @return configuration file path
     */
    private String getConfigFilePath() {
        String environment = System.getProperty(ENVIRONMENT_PROPERTY);
        String propertiesFilename = PROPERTIES_FILE_NAME;

        if (environment != null) {
            propertiesFilename = environment + "." + PROPERTIES_FILE_NAME;
        }
        String configFilePath = PROPERTIES_FILE_PATH + propertiesFilename;

        return configFilePath;
    }
}