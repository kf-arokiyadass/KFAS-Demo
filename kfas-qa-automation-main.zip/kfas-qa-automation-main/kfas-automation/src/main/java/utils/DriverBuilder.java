package utils;

import dataProviders.ConfigProperties;
import enums.Browsers;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.config.OperatingSystem;
import io.github.bonigarcia.wdm.managers.*;
import loggers.LoggerHelper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.safari.SafariDriver;
import reusable.UIHelpers;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class DriverBuilder {

    private final static Logger log = LoggerHelper.getLogger(DriverBuilder.class);
    public final static String BROWSER_PROPERTY = "browser";

    public static WebDriver createDriver(String browser){

        WebDriver driver = null;

        if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
            WebDriverManager webDriverManager = new ChromeDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.chromedriver().clearCache();
            WebDriverManager.chromedriver().setup();
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("--no-sandbox");
            chromeOptions.addArguments("--disable-gpu");
            chromeOptions.addArguments("--disable-popup-blocking");
            chromeOptions.addArguments("--disable-dev-shm-usage");
            chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
            String headless = System.getProperties().getProperty("headless", null);
            if (headless == null || !headless.equals("false")) {
                log.info("Running Headless mode");
                chromeOptions.addArguments("--headless");
            }
            chromeOptions.addArguments("--disable-gpu", "--window-size=1920,1200", "--ignore-certificate-errors");
            if(ConfigProperties.getConfigProperties().checkPropertyExists("DOWNLOAD_PATH")) {
                String downloadPath = ConfigProperties.getConfigProperties().getString("DOWNLOAD_PATH");
                if (downloadPath != null) {
                    Map<String, Object> prefs = new HashMap<String, Object>();
                    prefs.put("download.default_directory", downloadPath);
                    chromeOptions.setExperimentalOption("prefs", prefs);
                }
            }
            driver = new ChromeDriver(chromeOptions);
            log.info("Chrome browser initiated");
        } else if (browser.equalsIgnoreCase(Browsers.IE.name())) {
            WebDriverManager webDriverManager = new InternetExplorerDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.iedriver().clearCache();
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
            log.info("IE browser initiated");
        } else if (browser.equalsIgnoreCase(Browsers.FIREFOX.name())) {
            WebDriverManager webDriverManager = new FirefoxDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.firefoxdriver().clearCache();
            WebDriverManager.firefoxdriver().setup();
            FirefoxOptions option = new FirefoxOptions();
            if(ConfigProperties.getConfigProperties().checkPropertyExists("DOWNLOAD_PATH")) {
                String downloadPath = ConfigProperties.getConfigProperties().getString("DOWNLOAD_PATH");
                if (downloadPath != null) {
                    FirefoxProfile profile = new FirefoxProfile();
                    profile.setPreference("browser.download.folderList", 2);
                    profile.setPreference("browser.download.dir", downloadPath);
                    profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
                            "text/csv,application/java-archive, application/x-msexcel,application/excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document," +
                                    "application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/vnd.microsoft.portable-executable");
                    option.setProfile(profile);
                }
            }
            driver = new FirefoxDriver(option);
            log.info("Firefox browser initiated");
        } else if (browser.equalsIgnoreCase(Browsers.EDGE.name())) {
            WebDriverManager webDriverManager = new EdgeDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.edgedriver().clearCache();
            WebDriverManager.edgedriver().setup();

            driver = new EdgeDriver();
            log.info("Edge browser initiated");
        } else if (browser.equalsIgnoreCase(Browsers.SAFARI.name())) {
            WebDriverManager webDriverManager = new PhantomJsDriverManager();
            webDriverManager.operatingSystem(OperatingSystem.WIN);
            WebDriverManager.phantomjs().clearCache();
            WebDriverManager.phantomjs().setup();
            driver = new SafariDriver();
            log.info("Safari browser initiated");
        }

        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        return driver;
    }
}
