package enums;

public enum Browsers {
    CHROME,
    FIREFOX,
    IE,
    EDGE,
    SAFARI
}
