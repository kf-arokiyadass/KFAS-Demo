package loggers;

import java.util.logging.Logger;

// log info prints data in console just like system. out.print statement
public class LoggerHelper {
    private static boolean root = false;

    public static Logger getLogger(Class<?> cls) {
        if (root) {
            return Logger.getLogger(cls.getSimpleName());
        }
        root = true;
        return Logger.getLogger(cls.getSimpleName());
    }
}
